# iPhone Sales Analysis using Python  

I collected a dataset from Kaggle for the task of analyzing iPhone sales, which includes data about the sales of iPhones in India on Flipkart. This dataset is ideal for analyzing iPhone sales in India, and it is available for download at the following link : [Kaggle](https://www.kaggle.com/datasets/komalkhetlani/apple-iphone-data).
